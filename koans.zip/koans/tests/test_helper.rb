require "minitest/autorun"
require "rake"

Rake.application.load_rakefile