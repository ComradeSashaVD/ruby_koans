puts  [1,5,7.8].sum
puts "He said, \"Don't\""
puts 'He said, "Don\'t"'
puts %(flexible quotes can handle both ' and " characters)
long_string = %{
It was the best of times,
It was the worst of times.
}
puts long_string